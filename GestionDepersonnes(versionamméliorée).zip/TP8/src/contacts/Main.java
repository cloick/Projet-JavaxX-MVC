package contacts;
	
import java.util.Optional;

import javafx.application.Application;
import javafx.stage.Stage;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.control.ButtonType;
import javafx.scene.layout.AnchorPane;
import javafx.scene.layout.Pane;
import javafx.fxml.FXMLLoader;
 

public class Main extends Application {
	
	static Scene scene;
	static ModelPersonne modelPersonne;
	static Pane panePersonneListe;
	static Pane panePersonneForm;
	static Stage primaryStage;
	
	public static ModelPersonne getModelPersonne() {
		return modelPersonne;
	}
	
	public static void showViewPersonneListe() {
		scene.setRoot(panePersonneListe);
	}
	
	public static void showViewPersonneForm() {
		scene.setRoot(panePersonneForm);
	}
	
	@Override
	public void start(Stage primaryStage) {
		try {
			Main.primaryStage = primaryStage;
			modelPersonne = new ModelPersonne();
			panePersonneListe = FXMLLoader.load(getClass().getResource("ViewPersonneListe.fxml"));
			panePersonneForm = FXMLLoader.load(getClass().getResource("ViewPersonneForm.fxml"));
			scene = new Scene(panePersonneListe);
			Main.showViewPersonneListe();
			//AnchorPane root = (AnchorPane)FXMLLoader.load(getClass().getResource("ViewPersonneListe.fxml"));
			//Scene scene = new Scene(root);
			scene.getStylesheets().add(getClass().getResource("application.css").toExternalForm());
			primaryStage.setScene(scene);
			primaryStage.show();
			
			
		} catch(Exception e) {
			e.printStackTrace();
		}
	}
	
	public static void afficherMessage(String message, AlertType type) {
		final Alert alert = new Alert(type);
		alert.initOwner(primaryStage);
		alert.setHeaderText(message);
		alert.showAndWait();
		}
	
	public static boolean demanderConfirmation(String message) {
		final Alert alert = new Alert(Alert.AlertType.CONFIRMATION);
		alert. initOwner(primaryStage);
		alert.setHeaderText(message);
		final Optional<ButtonType> result = alert.showAndWait();
		return result.get() == ButtonType.OK;
	}
	
	public static void main(String[] args) {
		launch(args);
	}
	
	
}
