package contacts;

import javafx.collections.ListChangeListener;
import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.ListView;
import javafx.scene.input.MouseButton;
import javafx.scene.input.MouseEvent;

public class ControllerPersonneListe {
	
	@FXML
	private ListView<Personne> listViewPersonnes;
	@FXML
	private Button BAjouter;
	@FXML
	private Button BModifier;
	@FXML
	private Button BSupprimer;
	@FXML
	private Button BActualiser;

	private ModelPersonne modelPersonne;

	
	@FXML
	private void initialize() {
		modelPersonne = Main.getModelPersonne();
		
		listViewPersonnes.setItems(modelPersonne.getPersonnes());

		listViewPersonnes.getSelectionModel().getSelectedItems().addListener(
				(ListChangeListener<Personne>) (c) -> {
					if(!(listViewPersonnes.getSelectionModel().getSelectedItems().isEmpty())) {
						BModifier.setDisable(false);
						BSupprimer.setDisable(false);
					}
				});
	}

	
	@FXML
	private void doAjouter() {
		modelPersonne.preparerAjouter();
		ControllerPersonneForm.setAjouterB(true);
		Main.showViewPersonneForm();
	}
	@FXML
	private void doModifier() {
		modelPersonne.preparerModifier(listViewPersonnes.getSelectionModel().getSelectedItem());
		Main.showViewPersonneForm();
	}
	@FXML
	private void doSupprimer() {
		if(Main.demanderConfirmation("�tes-vous s�r de vouloir supprimer "+listViewPersonnes.getSelectionModel().getSelectedItem() +" ?")==true)
			modelPersonne.Supprimer(listViewPersonnes.getSelectionModel().getSelectedItem());

	}
	@FXML
	private void doActualiser() {
		modelPersonne.actualiserListe();	
	}
	@FXML
	private void gererClic(MouseEvent event) {
		if (event.getButton().equals(MouseButton.PRIMARY)) {
			if (event.getClickCount() == 2) {
				this.doModifier();
			}
		}
	}
}
