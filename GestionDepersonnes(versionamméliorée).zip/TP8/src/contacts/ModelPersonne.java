package contacts;

import javafx.beans.Observable;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.scene.control.Alert.AlertType;

public class ModelPersonne {
	
	private final ObservableList<Personne> personnes = FXCollections.observableArrayList( p -> new Observable[] { p.nomProperty(), p.prenomProperty()});
	private final Personne personneVue = new Personne(00, "XXXXX", "Xxxxx");
	private static int trackerNbr = 1;
	
	
	public ModelPersonne() {
		actualiserListe();
	}
	
	
	public ObservableList<Personne> getPersonnes() {
		return personnes;
	}
	
	public Personne getPersonneVue() {
		return personneVue;
	}
	
	
	public void actualiserListe() {
		Personne p = new Personne(1,"DUBOIS","Jean");
		Personne p1 = new Personne(2,"DUPONT","Marie");
		Personne p2 = new Personne(3,"DURAND","Pierre");
		personnes.add(p);
		personnes.add(p1);
		personnes.add(p2);
	}
	
	private Personne personneCourant = new Personne();
	
	public void Supprimer(Personne p) {
		if (personnes.contains(p)) {
			personnes.remove(p);
			trackerNbr++;
		}
	}
	
	public Personne copierDonnees(Personne source, Personne cible) {
		cible.setId(source.getId());
		cible.setNom(source.getNom());
		cible.setPrenom(source.getPrenom());
		cible.getTelephones().clear();
		for(int i=0;i<source.getTelephones().size();i++) {
			Telephone t = source.getTelephones().get(i);
			cible.getTelephones().add(new Telephone(t.getId(),t.getLibelle(),t.getNumero()));
		}
		return cible;
	}

	public Personne getPersonneCourant() {
		return personneCourant;
	}
	
	public void preparerModifier(Personne personne) {
		personneCourant = personne;
		this.copierDonnees(personneCourant, personneVue);
	}
	
	public void ValiderMiseAJour() {
		
		if (personneVue.getNom().isBlank()) {
			Main.afficherMessage("Le nom ne doit pas �tre vide.", AlertType.ERROR);
		}
		else if (personneVue.getPrenom().isBlank()) {
			Main.afficherMessage("Le pr�nom ne doit pas �tre vide.", AlertType.ERROR);
		}
		else if (personneVue.getNom().length()>25) {
			Main.afficherMessage("La longueur du nom ne doit pas exc�der 25 caract�res.", AlertType.ERROR);
		}
		else if (personneVue.getPrenom().length()>25) {
			Main.afficherMessage("La longueur du pr�nom ne doit pas exc�der 25 caract�res.", AlertType.ERROR);
		}
		else {
			if(ControllerPersonneForm.getAjouterB() && !(this.getPersonnes().contains(personneVue))) {
				Personne personneAjout = new Personne(personneVue.getId(),personneVue.getNom(),personneVue.getPrenom());
				personnes.add(personneAjout);
			}
			this.copierDonnees(personneVue, personneCourant);
			Main.showViewPersonneListe();
		}
	}
	
	public void ajouterTelephone() {
		Telephone t = new Telephone();
		Telephone.idTotal++;
		personneVue.getTelephones().add(t);
	}
	
	public void supprimerTelephone(Telephone t) {
		personneVue.getTelephones().remove(t);
		Telephone.idTotal--;
	}
	
	public void preparerAjouter() {
		Personne personneAjout = new Personne(this.getPersonnes().size()+trackerNbr,"","");
		this.copierDonnees(personneAjout, personneVue);
	}
	
	
	
	
	
	
	
	
	
	
	
}
