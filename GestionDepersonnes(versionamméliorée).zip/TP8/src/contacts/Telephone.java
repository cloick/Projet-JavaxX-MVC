package contacts;

import javafx.beans.property.IntegerProperty;
import javafx.beans.property.SimpleIntegerProperty;
import javafx.beans.property.SimpleStringProperty;
import javafx.beans.property.StringProperty;

public class Telephone {
	public static int idTotal = 0;
	private final IntegerProperty id = new SimpleIntegerProperty();
	private final StringProperty libelle = new SimpleStringProperty();
	private final StringProperty numero = new SimpleStringProperty();
	
	public Telephone(int id, String libelle, String numero) {
		this.setId(id);
		this.setLibelle(libelle);
		this.setNumero(numero);
	}
	
	public Telephone() {
		this.setId(idTotal);
	}
	
		
	public final IntegerProperty idProperty() {
		return this.id;
	}
	public final int getId() {
		return this.idProperty().get();
	}
	public final void setId(final int id) {
		this.idProperty().set(id);
	}
	
	public final StringProperty libelleProperty() {
		return this.libelle;
	}
	public final String getLibelle() {
		return this.libelleProperty().get();
	}
	public final void setLibelle(final String l) {
		this.libelleProperty().set(l);
	}
	 
	public final StringProperty numeroProperty() {
		return this.numero;
	}
	public final String getNumero() {
		return this.numeroProperty().get();
	}
	public final void setNumero(final String n) {
		this.numeroProperty().set(n);
	}
	@Override
	public String toString() {
		return "Telephone "+this.getId()+" "+this.getLibelle()+" "+this.getNumero();
	}
	
	
	
	
	
	
	
	
	
	
}
