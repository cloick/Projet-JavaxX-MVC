package contacts;

import javafx.beans.binding.Bindings;
import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.ContextMenu;
import javafx.scene.control.MenuItem;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;

public class ControllerPersonneForm {
	@FXML
	private Button BValider;
	@FXML
	private Button BAnnuler;
	@FXML
	private TextField tfId;
	@FXML
	private TextField tfNom;
	@FXML
	private TextField tfPrenom;
	@FXML
	private TableView <Telephone> tvTelephone;
	@FXML
	private TableColumn <Telephone, Number> columnId;
	@FXML
	private TableColumn <Telephone, String> columnLibelle;
	@FXML
	private TableColumn <Telephone, String> columnNumero;
	@FXML
	private ContextMenu contextMenu = new ContextMenu();
	@FXML
	private MenuItem itemA = new MenuItem();
	
	private ModelPersonne modelPersonne;
	
	private static boolean Ajouter = false;
	
	@FXML
	private void initialize() {
		modelPersonne = Main.getModelPersonne();
		
		Personne personneVue = modelPersonne.getPersonneVue();
		tfId.textProperty().bind( Bindings.convert(personneVue.idProperty()));
		tfNom.textProperty().bindBidirectional(personneVue.nomProperty());
		tfPrenom.textProperty().bindBidirectional(personneVue.prenomProperty());
		
		tvTelephone.setItems(personneVue.getTelephones());
		columnId.setCellValueFactory( cellData -> cellData.getValue().idProperty());
		columnLibelle.setCellValueFactory( cellData -> cellData.getValue().libelleProperty());
		columnNumero.setCellValueFactory( cellData -> cellData.getValue().numeroProperty());
		columnLibelle.setCellFactory( column -> new EditingCell<>());
		columnNumero.setCellFactory( column -> new EditingCell<>());

	}
	 
	@FXML
	private void doValider() {
		modelPersonne.ValiderMiseAJour();
	}
	@FXML
	private void doAnnuler() {
		Main.showViewPersonneListe();
	}
	@FXML
	private void doAjouterTelephone() {
		modelPersonne.ajouterTelephone();
	}
	@FXML
	private void doSupprimerTelephone() {
		modelPersonne.supprimerTelephone(tvTelephone.getSelectionModel().getSelectedItem());
	}
	
	@FXML
	public static void setAjouterB(boolean b) {
		Ajouter = b;
	}
	
	@FXML
	public static boolean getAjouterB() {
		return Ajouter;
	}
	
	
	
}


