module TP8 {
	requires javafx.controls;
	requires javafx.fxml;
	requires javafx.base;
	requires javafx.graphics;
	
	opens contacts to javafx.graphics, javafx.fxml;
}
