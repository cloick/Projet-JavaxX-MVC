package application;

import application.data.Personne;
import javafx.beans.Observable;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;

public class ModelPersonne {

	private final ObservableList<Personne> personnes = FXCollections
			.observableArrayList(p -> new Observable[] { p.nomProperty(), p.prenomProperty() });

	private Personne personneVue = new Personne(99, "XXXXX", "Xxxxx");

	private Personne personneCourant;

	public ModelPersonne() {
		actualiserListe();
	}

	public void actualiserListe() {
		personnes.clear();
		personnes.add(new Personne(1, "DUBOIS", "Jean"));
		personnes.add(new Personne(2, "DUPONT", "Marie"));
		personnes.add(new Personne(3, "DURAND", "Pierre"));
	}

	public Personne getPersonneVue() {
		return personneVue;
	}

	public ObservableList<Personne> getPersonnes() {
		return personnes;
	}

	public void supprimer(Personne p) {
		personnes.remove(p);
	}

	public void preparerAjouter() {
		Main.ajouter = true;
		personneVue.setId(personnes.size() + 1);
		personneVue.setNom("");
		personneVue.setPrenom("");
	}

	public void preparerModifier(Personne personne) {
		Main.modifier = true;
		personneCourant = personne;
		copierDonnees(personne, personneVue);

	}

	public void ValiderMiseAJour() {
		if (Main.ajouter) {
			Personne newpers = new Personne();
			copierDonnees(personneVue, newpers);
			personnes.add(newpers);
		}
		if (Main.modifier) {
			copierDonnees(personneVue, personneCourant);
		}
		Main.ajouter = false;
		Main.modifier = false;
	}

	// M�thodes auxiliaires
	private Personne copierDonnees(Personne source, Personne cible) {
		cible.setId(source.getId());
		cible.setNom(source.getNom());
		cible.setPrenom(source.getPrenom());
		return cible;
	}

}
