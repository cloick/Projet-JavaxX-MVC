package application;
	
import java.io.IOException;

import javafx.application.Application;
import javafx.stage.Stage;
import javafx.scene.Scene;
import javafx.scene.layout.AnchorPane;
import javafx.scene.layout.Pane;
import javafx.fxml.FXMLLoader;


public class Main extends Application {
	
	private static Scene scene;
	private static ModelPersonne modelPersonne;
	private static Pane panePersonneListe;
	private static Pane panePersonneForm;
	
	public static boolean ajouter;
	public  static boolean modifier;
	
	@Override
	public void start(Stage primaryStage) throws IOException {
		
		modelPersonne = new ModelPersonne();
		panePersonneListe = FXMLLoader.load(getClass().getResource("Sample.fxml"));
		panePersonneForm = FXMLLoader.load(getClass().getResource("ViewPersonneForm.fxml"));
		scene = new Scene(panePersonneListe);
		
		try {
			
			//AnchorPane panePersonneListe = (AnchorPane)FXMLLoader.load(getClass().getResource("Sample.fxml"));
			//Scene scene = new Scene(panePersonneListe);
			scene.getStylesheets().add(getClass().getResource("application.css").toExternalForm());
			primaryStage.setScene(Main.scene);
			primaryStage.show();
		} catch(Exception e) {
			e.printStackTrace();
		}
	}
	
	public static void main(String[] args) {
		launch(args);
	}
	
	public static void showViewPersonneListe() {
		scene.setRoot(panePersonneListe);
	}
	
	public static void showViewPersonneForm() {
		scene.setRoot(panePersonneForm);
	}
	
	public static ModelPersonne getModelPersonne() {
		return modelPersonne;
	}
}
