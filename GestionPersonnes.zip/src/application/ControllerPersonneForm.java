package application;

import application.data.Personne;
import javafx.beans.binding.Bindings;
import javafx.fxml.FXML;
import javafx.scene.control.TextField;

public class ControllerPersonneForm {

	@FXML
	private TextField textFieldId;
	@FXML
	private TextField textFieldNom;
	@FXML
	private TextField textFieldPrenom;

	@FXML
	private ModelPersonne modelPersonne;

	@FXML
	void initialize() {
		modelPersonne = Main.getModelPersonne();
 
		Personne personneVue = modelPersonne.getPersonneVue();
		textFieldId.textProperty().bind(Bindings.convert(personneVue.idProperty()));
		textFieldNom.textProperty().bindBidirectional(personneVue.nomProperty());
		textFieldPrenom.textProperty().bindBidirectional(personneVue.prenomProperty());
	}

	@FXML
	private void doValider() {
		modelPersonne.ValiderMiseAJour();
		Main.showViewPersonneListe();

	}

	@FXML
	private void doAnnuler() {
		Main.showViewPersonneListe();
	}

}
