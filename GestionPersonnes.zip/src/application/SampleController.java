package application;

import application.data.Personne;
import javafx.fxml.FXML;
import javafx.scene.control.ListView;

public class SampleController {

	@FXML
	private ListView<Personne> listViewPersonnes;

	@FXML
	private ModelPersonne modelPersonne;

	@FXML
	void initialize() {
		// Injection des d�pendances
		modelPersonne = Main.getModelPersonne();
		// Data binding
		listViewPersonnes.setItems(modelPersonne.getPersonnes());
	}

	@FXML
	private void doAjouter() {
		modelPersonne.preparerAjouter();
		System.out.println("ajouter");
		Main.showViewPersonneForm();

	}
	@FXML
	private void doModifier() {
		modelPersonne.preparerModifier(listViewPersonnes.getSelectionModel().getSelectedItem());
		System.out.println("modifier " + listViewPersonnes.getSelectionModel().getSelectedItem().getNom() + " " + listViewPersonnes.getSelectionModel().getSelectedItem().getPrenom());
		Main.showViewPersonneForm();
	}
	@FXML
	private void doSupprimer() {
		System.out.println("supprimer " + listViewPersonnes.getSelectionModel().getSelectedItem().getNom() + " " + listViewPersonnes.getSelectionModel().getSelectedItem().getPrenom());
		modelPersonne.supprimer(listViewPersonnes.getSelectionModel().getSelectedItem());
	}
	@FXML
	private void doActualiser() {
		modelPersonne.actualiserListe();
	}
}
